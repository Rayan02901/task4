﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auction.Utility
{
    public static class SD
    {
        public const string Role_Buyer = "Buyer";
        public const string Role_Seller = "Seller";
        public const string Role_Admin = "Admin";
        
    }
}